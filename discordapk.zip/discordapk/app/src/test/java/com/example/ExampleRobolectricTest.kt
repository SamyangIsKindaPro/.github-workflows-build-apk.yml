package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.ActivityType
import com.example.data.model.RichPresencePayload
import com.example.ui.components.formatDuration
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `app name matches PulseRPC`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("PulseRPC", appName)
    }

    @Test
    fun `activity type mapping resolves correctly`() {
        assertEquals(ActivityType.PLAYING, ActivityType.fromCode(0))
        assertEquals(ActivityType.LISTENING, ActivityType.fromCode(2))
        assertEquals(ActivityType.COMPETING, ActivityType.fromCode(5))
        assertEquals(ActivityType.PLAYING, ActivityType.fromCode(99))
    }

    @Test
    fun `formatDuration renders mm ss and hh mm ss`() {
        assertEquals("00:45", formatDuration(45))
        assertEquals("05:09", formatDuration(309))
        assertEquals("01:02:03", formatDuration(3723))
    }

    @Test
    fun `default payload has valid application id`() {
        val payload = RichPresencePayload(name = "Test Game")
        assertEquals(RichPresencePayload.DEFAULT_DISCORD_APP_ID, payload.applicationId)
        assertEquals(ActivityType.PLAYING, payload.activityType)
    }
}
