package com.example.ui.screens

import android.text.format.DateUtils
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.HourglassBottom
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.QueryStats
import androidx.compose.material.icons.rounded.Sensors
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import com.example.data.model.BroadcastMode
import com.example.data.model.InstalledAppInfo
import com.example.ui.MainUiState
import com.example.ui.components.DiscordPresenceCard
import com.example.ui.components.GatewayStatusPill
import com.example.ui.components.PermissionStatusCard
import com.example.ui.components.SectionHeader
import com.example.ui.theme.AlertCoral
import com.example.ui.theme.Blurple
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.OnlineGreen
import com.example.ui.theme.OnlineGreenBright

@Composable
fun LiveDashboardScreen(
    uiState: MainUiState,
    onToggleBroadcast: (Boolean) -> Unit,
    onSelectMode: (BroadcastMode) -> Unit,
    onToggleKeepOnLeave: (Boolean) -> Unit,
    onSetLeaveDelaySeconds: (Int) -> Unit,
    onSetCustomElapsed: (Boolean, Int, Int) -> Unit,
    onOpenUsageSettings: () -> Unit,
    onOpenNotificationListenerSettings: () -> Unit,
    onRequestPostNotifications: () -> Unit,
    onNavigateToConnect: () -> Unit,
    onSelectPreviewApp: (InstalledAppInfo?) -> Unit,
    onNavigateToApps: () -> Unit,
    modifier: Modifier = Modifier
) {
    val prefs = uiState.preferences
    val isBroadcasting = prefs.isBroadcastingActive
    val buttonContainerColor by animateColorAsState(
        targetValue = if (isBroadcasting) AlertCoral else Blurple,
        label = "broadcast_cta_color"
    )

    val activeIcon = remember(uiState.activePresence.sourcePackageName, uiState.installedApps) {
        uiState.resolveAppIcon(uiState.activePresence.sourcePackageName)
    }

    var showLeaveDelayDialog by remember { mutableStateOf(false) }
    var showElapsedOffsetDialog by remember { mutableStateOf(false) }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 680.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Top Brand Bar
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "PulseRPC",
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Mobile Rich Presence",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    GatewayStatusPill(
                        status = uiState.gatewayState.status,
                        pingMs = uiState.gatewayState.pingMs,
                        onClick = onNavigateToConnect
                    )
                }
            }

            // Hero Discord Rich Presence Preview Card
            item {
                DiscordPresenceCard(
                    payload = uiState.activePresence,
                    user = uiState.gatewayState.user,
                    gatewayStatus = uiState.gatewayState.status,
                    isBroadcasting = isBroadcasting,
                    appIconDrawable = activeIcon,
                    modifier = Modifier.testTag("live_presence_card")
                )
            }

            // Master Broadcast Control + Mode Switcher
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    color = MaterialTheme.colorScheme.surfaceContainer,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Button(
                            onClick = { onToggleBroadcast(!isBroadcasting) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(54.dp)
                                .testTag("broadcast_toggle_button"),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = buttonContainerColor,
                                contentColor = Color.White
                            )
                        ) {
                            Icon(
                                imageVector = if (isBroadcasting) Icons.Rounded.Stop else Icons.Rounded.PlayArrow,
                                contentDescription = null,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isBroadcasting) "Stop Broadcasting" else "Start Rich Presence",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // Mode Selector Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            BroadcastMode.entries.forEach { mode ->
                                val selected = prefs.broadcastMode == mode
                                val modeIcon = when (mode) {
                                    BroadcastMode.AUTO_APP -> Icons.Rounded.Apps
                                    BroadcastMode.MEDIA -> Icons.Rounded.MusicNote
                                    BroadcastMode.CUSTOM -> Icons.Rounded.Tune
                                }
                                Surface(
                                    onClick = { onSelectMode(mode) },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(48.dp)
                                        .testTag("mode_chip_${mode.name.lowercase()}"),
                                    shape = RoundedCornerShape(14.dp),
                                    color = if (selected) {
                                        Blurple.copy(alpha = 0.2f)
                                    } else {
                                        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)
                                    },
                                    border = BorderStroke(
                                        1.dp,
                                        if (selected) Blurple else MaterialTheme.colorScheme.outline.copy(alpha = 0.45f)
                                    )
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.Center
                                    ) {
                                        Icon(
                                            imageVector = modeIcon,
                                            contentDescription = null,
                                            tint = if (selected) Blurple else MaterialTheme.colorScheme.onSurfaceVariant,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = mode.label,
                                            style = MaterialTheme.typography.labelMedium,
                                            color = if (selected) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Session Timer & Leave Grace Card
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    color = MaterialTheme.colorScheme.surfaceContainer,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        SectionHeader(
                            title = "Session Timer & Leave Grace",
                            subtitle = "Keep presence after leaving & customize elapsed start time"
                        )

                        // Leave Grace Period Control
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = NeonCyan.copy(alpha = 0.14f),
                                    modifier = Modifier.size(38.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Rounded.HourglassBottom,
                                            contentDescription = null,
                                            tint = NeonCyan,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                                Column {
                                    Text(
                                        text = "Keep Presence After Leaving",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = if (prefs.keepPresenceOnLeaveEnabled) {
                                            "Wait ${prefs.leaveDelaySeconds}s before clearing; resumes if reopened"
                                        } else {
                                            "Removes immediately when you leave the app"
                                        },
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            Switch(
                                checked = prefs.keepPresenceOnLeaveEnabled,
                                onCheckedChange = onToggleKeepOnLeave,
                                modifier = Modifier.testTag("keep_presence_leave_switch")
                            )
                        }

                        AnimatedVisibility(visible = prefs.keepPresenceOnLeaveEnabled) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                listOf(10, 30, 60, 120).forEach { sec ->
                                    FilterChip(
                                        selected = prefs.leaveDelaySeconds == sec,
                                        onClick = { onSetLeaveDelaySeconds(sec) },
                                        label = { Text("${sec}s") }
                                    )
                                }
                                Spacer(modifier = Modifier.weight(1f))
                                OutlinedButton(
                                    onClick = { showLeaveDelayDialog = true },
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                    modifier = Modifier.testTag("edit_leave_delay_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Edit,
                                        contentDescription = "Edit leave delay seconds",
                                        modifier = Modifier.size(15.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "${prefs.leaveDelaySeconds}s",
                                        style = MaterialTheme.typography.labelMedium.copy(fontFamily = JetBrainsMonoFamily)
                                    )
                                }
                            }
                        }

                        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))

                        // Custom Elapsed Offset Control
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = Blurple.copy(alpha = 0.16f),
                                    modifier = Modifier.size(38.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Rounded.Timer,
                                            contentDescription = null,
                                            tint = Blurple,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                                Column {
                                    Text(
                                        text = "Custom Elapsed Time",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = if (prefs.customElapsedEnabled) {
                                            "Starts counting from ${prefs.customElapsedMinutes}m ${prefs.customElapsedSeconds}s"
                                        } else {
                                            "Tap toggle to start timer from e.g. 36 mins"
                                        },
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            Switch(
                                checked = prefs.customElapsedEnabled,
                                onCheckedChange = { enabled ->
                                    onSetCustomElapsed(
                                        enabled,
                                        prefs.customElapsedMinutes,
                                        prefs.customElapsedSeconds
                                    )
                                },
                                modifier = Modifier.testTag("custom_elapsed_switch")
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf(15, 36, 60, 120).forEach { mins ->
                                FilterChip(
                                    selected = prefs.customElapsedEnabled &&
                                        prefs.customElapsedMinutes == mins &&
                                        prefs.customElapsedSeconds == 0,
                                    onClick = { onSetCustomElapsed(true, mins, 0) },
                                    label = {
                                        Text(if (mins >= 60) "${mins / 60}h" else "${mins}m")
                                    }
                                )
                            }
                            Spacer(modifier = Modifier.weight(1f))
                            OutlinedButton(
                                onClick = { showElapsedOffsetDialog = true },
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                modifier = Modifier.testTag("edit_custom_elapsed_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Edit,
                                    contentDescription = "Edit custom elapsed time",
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "${prefs.customElapsedMinutes}m ${prefs.customElapsedSeconds}s",
                                    style = MaterialTheme.typography.labelMedium.copy(fontFamily = JetBrainsMonoFamily)
                                )
                            }
                        }
                    }
                }
            }

            // Permission Readiness Section
            item {
                val perms = uiState.permissions
                val allGranted = perms.hasUsageStats && perms.hasNotificationListener && perms.hasPostNotifications
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    SectionHeader(
                        title = "Detection Permissions",
                        subtitle = if (allGranted) {
                            "All Android sensors active"
                        } else {
                            "Grant access so PulseRPC can detect games & music"
                        }
                    )

                    PermissionStatusCard(
                        title = "App Usage Access",
                        subtitle = if (perms.hasUsageStats) {
                            "Active • Detecting foreground games & apps"
                        } else {
                            "Tap to allow UsageStatsManager app detection"
                        },
                        granted = perms.hasUsageStats,
                        icon = Icons.Rounded.QueryStats,
                        testTag = "perm_usage_stats_card",
                        onClick = onOpenUsageSettings
                    )

                    PermissionStatusCard(
                        title = "Media Notification Access",
                        subtitle = if (perms.hasNotificationListener) {
                            "Active • Reading Spotify, YT Music & players"
                        } else {
                            "Tap to enable Now Playing media detection"
                        },
                        granted = perms.hasNotificationListener,
                        icon = Icons.Rounded.Sensors,
                        testTag = "perm_notification_listener_card",
                        onClick = onOpenNotificationListenerSettings
                    )

                    AnimatedVisibility(visible = !perms.hasPostNotifications) {
                        PermissionStatusCard(
                            title = "Service Notification",
                            subtitle = "Required on Android 13+ to keep background service alive",
                            granted = perms.hasPostNotifications,
                            icon = Icons.Rounded.NotificationsActive,
                            testTag = "perm_post_notifications_card",
                            onClick = onRequestPostNotifications
                        )
                    }
                }
            }

            // Quick Installed App Preview Switcher
            if (uiState.installedApps.isNotEmpty()) {
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        SectionHeader(
                            title = "Quick App Preview",
                            subtitle = if (uiState.manualPreviewApp != null) {
                                "Previewing ${uiState.manualPreviewApp.appName}"
                            } else {
                                "Tap an installed app to preview its Rich Presence"
                            },
                            trailing = {
                                if (uiState.manualPreviewApp != null) {
                                    IconButton(
                                        onClick = { onSelectPreviewApp(null) },
                                        modifier = Modifier.testTag("clear_preview_app_button")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.Close,
                                            contentDescription = "Clear preview app"
                                        )
                                    }
                                } else {
                                    Surface(
                                        onClick = onNavigateToApps,
                                        shape = RoundedCornerShape(50),
                                        color = MaterialTheme.colorScheme.surfaceVariant
                                    ) {
                                        Text(
                                            text = "All (${uiState.installedApps.size})",
                                            style = MaterialTheme.typography.labelMedium,
                                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                        )
                                    }
                                }
                            }
                        )

                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            val quickApps = uiState.installedApps
                                .sortedByDescending { it.isGame }
                                .take(12)
                            items(quickApps, key = { it.packageName }) { app ->
                                val isSelected = uiState.manualPreviewApp?.packageName == app.packageName
                                QuickAppChip(
                                    app = app,
                                    selected = isSelected,
                                    onClick = {
                                        onSelectPreviewApp(if (isSelected) null else app)
                                    }
                                )
                            }
                        }
                    }
                }
            }

            // Recent Presence Broadcast Timeline
            item {
                SectionHeader(
                    title = "Recent Activity",
                    subtitle = "Latest detected apps & broadcasted sessions"
                )
            }

            if (uiState.recentLogs.isEmpty()) {
                item {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                        color = MaterialTheme.colorScheme.surfaceContainer,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.History,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(32.dp)
                            )
                            Text(
                                text = "No broadcast sessions yet",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Start Rich Presence and switch to a game or music app to record your live sessions.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            } else {
                items(uiState.recentLogs, key = { it.id }) { log ->
                    val relativeTime = remember(log.timestampMs) {
                        DateUtils.getRelativeTimeSpanString(
                            log.timestampMs,
                            System.currentTimeMillis(),
                            DateUtils.MINUTE_IN_MILLIS
                        ).toString()
                    }
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surfaceContainer,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(OnlineGreenBright)
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = log.title,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = log.subtitle,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = OnlineGreen.copy(alpha = 0.15f)
                                ) {
                                    Text(
                                        text = log.modeLabel,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = OnlineGreenBright,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = relativeTime,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(12.dp)) }
        }
    }

    if (showLeaveDelayDialog) {
        var secondsText by remember(prefs.leaveDelaySeconds) {
            mutableStateOf(prefs.leaveDelaySeconds.toString())
        }
        AlertDialog(
            onDismissRequest = { showLeaveDelayDialog = false },
            title = { Text("Leave Grace Duration") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Keep showing Rich Presence for this many seconds after you leave the app.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedTextField(
                        value = secondsText,
                        onValueChange = { value -> secondsText = value.filter { it.isDigit() } },
                        label = { Text("Duration (seconds)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("leave_delay_seconds_input")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val parsed = secondsText.toIntOrNull()?.coerceIn(1, 3600) ?: 30
                        onToggleKeepOnLeave(true)
                        onSetLeaveDelaySeconds(parsed)
                        showLeaveDelayDialog = false
                    }
                ) {
                    Text("Apply")
                }
            },
            dismissButton = {
                TextButton(onClick = { showLeaveDelayDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    if (showElapsedOffsetDialog) {
        var minutesText by remember(prefs.customElapsedMinutes) {
            mutableStateOf(prefs.customElapsedMinutes.toString())
        }
        var secondsText by remember(prefs.customElapsedSeconds) {
            mutableStateOf(prefs.customElapsedSeconds.toString())
        }
        AlertDialog(
            onDismissRequest = { showElapsedOffsetDialog = false },
            title = { Text("Custom Elapsed Time") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Choose how much time has already passed since your Rich Presence started (e.g., 36 mins).",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = minutesText,
                            onValueChange = { value -> minutesText = value.filter { it.isDigit() } },
                            label = { Text("Minutes") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("custom_elapsed_minutes_input")
                        )
                        OutlinedTextField(
                            value = secondsText,
                            onValueChange = { value -> secondsText = value.filter { it.isDigit() } },
                            label = { Text("Seconds") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("custom_elapsed_seconds_input")
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val mins = minutesText.toIntOrNull()?.coerceIn(0, 1440) ?: 36
                        val secs = secondsText.toIntOrNull()?.coerceIn(0, 59) ?: 0
                        onSetCustomElapsed(true, mins, secs)
                        showElapsedOffsetDialog = false
                    },
                    modifier = Modifier.testTag("apply_custom_elapsed_button")
                ) {
                    Text("Enable & Apply")
                }
            },
            dismissButton = {
                TextButton(onClick = { showElapsedOffsetDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun QuickAppChip(
    app: InstalledAppInfo,
    selected: Boolean,
    onClick: () -> Unit
) {
    val iconBitmap = remember(app.packageName) {
        app.icon?.let { runCatching { it.toBitmap(96, 96).asImageBitmap() }.getOrNull() }
    }

    Surface(
        onClick = onClick,
        modifier = Modifier
            .width(96.dp)
            .testTag("quick_app_chip_${app.packageName}"),
        shape = RoundedCornerShape(16.dp),
        color = if (selected) {
            Blurple.copy(alpha = 0.22f)
        } else {
            MaterialTheme.colorScheme.surfaceContainer
        },
        border = BorderStroke(
            1.dp,
            if (selected) Blurple else MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
        )
    ) {
        Column(
            modifier = Modifier
                .clickable(onClick = onClick)
                .padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            if (iconBitmap != null) {
                Image(
                    bitmap = iconBitmap,
                    contentDescription = app.appName,
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(10.dp)),
                    contentScale = ContentScale.Fit
                )
            } else {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Apps,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
            Text(
                text = app.appName,
                style = MaterialTheme.typography.labelMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}
