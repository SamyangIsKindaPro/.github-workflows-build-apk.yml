package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.ActivityType
import com.example.data.model.RichPresencePayload

@Entity(tableName = "app_rules")
data class AppRuleEntity(
    @PrimaryKey val packageName: String,
    val appName: String,
    val isEnabled: Boolean = true,
    val isCustomized: Boolean = false,
    val customTitle: String = "",
    val customDetails: String = "",
    val customState: String = "",
    val activityTypeCode: Int = ActivityType.PLAYING.code,
    val applicationId: String = RichPresencePayload.DEFAULT_DISCORD_APP_ID,
    val largeImageUrl: String = "",
    val largeImageText: String = "",
    val smallImageUrl: String = "",
    val smallImageText: String = "",
    val button1Label: String = "",
    val button1Url: String = "",
    val showElapsedTime: Boolean = true,
    val updatedAtMs: Long = System.currentTimeMillis()
)
