package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.ActivityType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [AppRuleEntity::class, PresencePresetEntity::class, ActivityLogEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun pulseRpcDao(): PulseRpcDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: buildDatabase(context.applicationContext).also { INSTANCE = it }
            }
        }

        private fun buildDatabase(appContext: Context): AppDatabase {
            return Room.databaseBuilder(
                appContext,
                AppDatabase::class.java,
                "pulserpc_database"
            )
                .addCallback(object : Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        CoroutineScope(Dispatchers.IO).launch {
                            seedStarterPresets(getInstance(appContext).pulseRpcDao())
                        }
                    }
                })
                .build()
        }

        private suspend fun seedStarterPresets(dao: PulseRpcDao) {
            val starterPresets = listOf(
                PresencePresetEntity(
                    presetName = "Ranked Grind",
                    activityName = "Mobile Legends: Bang Bang",
                    details = "Mythic Glory Push",
                    state = "In Party (3 of 5)",
                    activityTypeCode = ActivityType.COMPETING.code,
                    largeImageText = "Ranked Lobby",
                    button1Label = "Watch Stream",
                    button1Url = "https://discord.com",
                    showElapsedTime = true
                ),
                PresencePresetEntity(
                    presetName = "Late Night Vibes",
                    activityName = "Lo-Fi Radio",
                    details = "Midnight Beats & Chill",
                    state = "On Mobile",
                    activityTypeCode = ActivityType.LISTENING.code,
                    largeImageText = "Studio Session",
                    showElapsedTime = true
                ),
                PresencePresetEntity(
                    presetName = "Android Dev",
                    activityName = "PulseRPC Studio",
                    details = "Crafting Kotlin & Compose",
                    state = "Building APK",
                    activityTypeCode = ActivityType.PLAYING.code,
                    largeImageText = "Jetpack Compose",
                    showElapsedTime = true
                )
            )
            starterPresets.forEach { dao.upsertPreset(it) }
        }
    }
}
