package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.model.ActivityType
import com.example.data.model.BroadcastMode
import com.example.data.model.DiscordUser
import com.example.data.model.RichPresencePayload
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "pulserpc_prefs")

data class UserPreferences(
    val discordToken: String = "",
    val cachedUser: DiscordUser? = null,
    val broadcastMode: BroadcastMode = BroadcastMode.AUTO_APP,
    val isBroadcastingActive: Boolean = false,
    val defaultApplicationId: String = RichPresencePayload.DEFAULT_DISCORD_APP_ID,
    val pollingIntervalSec: Int = 4,
    val showElapsedTimer: Boolean = true,
    val ignoreSelfApp: Boolean = true,
    val autoReconnect: Boolean = true,
    val keepPresenceOnLeaveEnabled: Boolean = false,
    val leaveDelaySeconds: Int = 30,
    val customElapsedEnabled: Boolean = false,
    val customElapsedMinutes: Int = 36,
    val customElapsedSeconds: Int = 0,
    val customElapsedVersion: Long = 0L,
    val customName: String = "Android Studio Mobile",
    val customDetails: String = "Vibing on Mobile",
    val customState: String = "Connected via PulseRPC",
    val customTypeCode: Int = ActivityType.PLAYING.code,
    val customAppId: String = RichPresencePayload.DEFAULT_DISCORD_APP_ID,
    val customLargeImageUrl: String = "",
    val customLargeImageText: String = "",
    val customSmallImageUrl: String = "",
    val customSmallImageText: String = "",
    val customButton1Label: String = "",
    val customButton1Url: String = "",
    val customButton2Label: String = "",
    val customButton2Url: String = "",
    val customShowElapsed: Boolean = true
) {
    val customElapsedOffsetMs: Long
        get() = ((customElapsedMinutes.coerceAtLeast(0) * 60L) + customElapsedSeconds.coerceIn(0, 59)) * 1000L
}

class PreferencesManager(private val context: Context) {

    private object Keys {
        val DISCORD_TOKEN = stringPreferencesKey("discord_token")
        val USER_ID = stringPreferencesKey("user_id")
        val USER_NAME = stringPreferencesKey("user_name")
        val USER_GLOBAL_NAME = stringPreferencesKey("user_global_name")
        val USER_AVATAR_URL = stringPreferencesKey("user_avatar_url")
        val BROADCAST_MODE = stringPreferencesKey("broadcast_mode")
        val IS_BROADCASTING = booleanPreferencesKey("is_broadcasting")
        val DEFAULT_APP_ID = stringPreferencesKey("default_app_id")
        val POLLING_INTERVAL_SEC = intPreferencesKey("polling_interval_sec")
        val SHOW_ELAPSED_TIMER = booleanPreferencesKey("show_elapsed_timer")
        val IGNORE_SELF_APP = booleanPreferencesKey("ignore_self_app")
        val AUTO_RECONNECT = booleanPreferencesKey("auto_reconnect")

        val KEEP_PRESENCE_ON_LEAVE = booleanPreferencesKey("keep_presence_on_leave")
        val LEAVE_DELAY_SECONDS = intPreferencesKey("leave_delay_seconds")
        val CUSTOM_ELAPSED_ENABLED = booleanPreferencesKey("custom_elapsed_enabled")
        val CUSTOM_ELAPSED_MINUTES = intPreferencesKey("custom_elapsed_minutes")
        val CUSTOM_ELAPSED_SECONDS = intPreferencesKey("custom_elapsed_seconds")
        val CUSTOM_ELAPSED_VERSION = longPreferencesKey("custom_elapsed_version")

        // Custom Studio draft
        val CUSTOM_NAME = stringPreferencesKey("custom_name")
        val CUSTOM_DETAILS = stringPreferencesKey("custom_details")
        val CUSTOM_STATE = stringPreferencesKey("custom_state")
        val CUSTOM_TYPE_CODE = intPreferencesKey("custom_type_code")
        val CUSTOM_APP_ID = stringPreferencesKey("custom_app_id")
        val CUSTOM_LARGE_IMG = stringPreferencesKey("custom_large_img")
        val CUSTOM_LARGE_TXT = stringPreferencesKey("custom_large_txt")
        val CUSTOM_SMALL_IMG = stringPreferencesKey("custom_small_img")
        val CUSTOM_SMALL_TXT = stringPreferencesKey("custom_small_txt")
        val CUSTOM_BTN1_LABEL = stringPreferencesKey("custom_btn1_label")
        val CUSTOM_BTN1_URL = stringPreferencesKey("custom_btn1_url")
        val CUSTOM_BTN2_LABEL = stringPreferencesKey("custom_btn2_label")
        val CUSTOM_BTN2_URL = stringPreferencesKey("custom_btn2_url")
        val CUSTOM_SHOW_ELAPSED = booleanPreferencesKey("custom_show_elapsed")
    }

    val preferencesFlow: Flow<UserPreferences> = context.dataStore.data.map { prefs ->
        val uid = prefs[Keys.USER_ID].orEmpty()
        val cachedUser = if (uid.isNotBlank()) {
            DiscordUser(
                id = uid,
                username = prefs[Keys.USER_NAME].orEmpty(),
                globalName = prefs[Keys.USER_GLOBAL_NAME].orEmpty(),
                avatarUrl = prefs[Keys.USER_AVATAR_URL].orEmpty()
            )
        } else null

        val modeName = prefs[Keys.BROADCAST_MODE] ?: BroadcastMode.AUTO_APP.name
        val mode = runCatching { BroadcastMode.valueOf(modeName) }.getOrDefault(BroadcastMode.AUTO_APP)

        UserPreferences(
            discordToken = prefs[Keys.DISCORD_TOKEN].orEmpty(),
            cachedUser = cachedUser,
            broadcastMode = mode,
            isBroadcastingActive = prefs[Keys.IS_BROADCASTING] ?: false,
            defaultApplicationId = prefs[Keys.DEFAULT_APP_ID]?.ifBlank { RichPresencePayload.DEFAULT_DISCORD_APP_ID }
                ?: RichPresencePayload.DEFAULT_DISCORD_APP_ID,
            pollingIntervalSec = (prefs[Keys.POLLING_INTERVAL_SEC] ?: 4).coerceIn(2, 15),
            showElapsedTimer = prefs[Keys.SHOW_ELAPSED_TIMER] ?: true,
            ignoreSelfApp = prefs[Keys.IGNORE_SELF_APP] ?: true,
            autoReconnect = prefs[Keys.AUTO_RECONNECT] ?: true,
            keepPresenceOnLeaveEnabled = prefs[Keys.KEEP_PRESENCE_ON_LEAVE] ?: false,
            leaveDelaySeconds = (prefs[Keys.LEAVE_DELAY_SECONDS] ?: 30).coerceIn(1, 3600),
            customElapsedEnabled = prefs[Keys.CUSTOM_ELAPSED_ENABLED] ?: false,
            customElapsedMinutes = (prefs[Keys.CUSTOM_ELAPSED_MINUTES] ?: 36).coerceIn(0, 1440),
            customElapsedSeconds = (prefs[Keys.CUSTOM_ELAPSED_SECONDS] ?: 0).coerceIn(0, 59),
            customElapsedVersion = prefs[Keys.CUSTOM_ELAPSED_VERSION] ?: 0L,
            customName = prefs[Keys.CUSTOM_NAME] ?: "Android Studio Mobile",
            customDetails = prefs[Keys.CUSTOM_DETAILS] ?: "Vibing on Mobile",
            customState = prefs[Keys.CUSTOM_STATE] ?: "Connected via PulseRPC",
            customTypeCode = prefs[Keys.CUSTOM_TYPE_CODE] ?: ActivityType.PLAYING.code,
            customAppId = prefs[Keys.CUSTOM_APP_ID]?.ifBlank { RichPresencePayload.DEFAULT_DISCORD_APP_ID }
                ?: RichPresencePayload.DEFAULT_DISCORD_APP_ID,
            customLargeImageUrl = prefs[Keys.CUSTOM_LARGE_IMG].orEmpty(),
            customLargeImageText = prefs[Keys.CUSTOM_LARGE_TXT].orEmpty(),
            customSmallImageUrl = prefs[Keys.CUSTOM_SMALL_IMG].orEmpty(),
            customSmallImageText = prefs[Keys.CUSTOM_SMALL_TXT].orEmpty(),
            customButton1Label = prefs[Keys.CUSTOM_BTN1_LABEL].orEmpty(),
            customButton1Url = prefs[Keys.CUSTOM_BTN1_URL].orEmpty(),
            customButton2Label = prefs[Keys.CUSTOM_BTN2_LABEL].orEmpty(),
            customButton2Url = prefs[Keys.CUSTOM_BTN2_URL].orEmpty(),
            customShowElapsed = prefs[Keys.CUSTOM_SHOW_ELAPSED] ?: true
        )
    }

    suspend fun saveDiscordToken(token: String) {
        context.dataStore.edit { it[Keys.DISCORD_TOKEN] = token.trim() }
    }

    suspend fun saveCachedUser(user: DiscordUser?) {
        context.dataStore.edit { prefs ->
            if (user == null) {
                prefs.remove(Keys.USER_ID)
                prefs.remove(Keys.USER_NAME)
                prefs.remove(Keys.USER_GLOBAL_NAME)
                prefs.remove(Keys.USER_AVATAR_URL)
            } else {
                prefs[Keys.USER_ID] = user.id
                prefs[Keys.USER_NAME] = user.username
                prefs[Keys.USER_GLOBAL_NAME] = user.globalName
                prefs[Keys.USER_AVATAR_URL] = user.avatarUrl
            }
        }
    }

    suspend fun setBroadcastMode(mode: BroadcastMode) {
        context.dataStore.edit { it[Keys.BROADCAST_MODE] = mode.name }
    }

    suspend fun setBroadcastingActive(active: Boolean) {
        context.dataStore.edit { it[Keys.IS_BROADCASTING] = active }
    }

    suspend fun setPollingIntervalSec(seconds: Int) {
        context.dataStore.edit { it[Keys.POLLING_INTERVAL_SEC] = seconds.coerceIn(2, 15) }
    }

    suspend fun setShowElapsedTimer(enabled: Boolean) {
        context.dataStore.edit { it[Keys.SHOW_ELAPSED_TIMER] = enabled }
    }

    suspend fun setIgnoreSelfApp(ignore: Boolean) {
        context.dataStore.edit { it[Keys.IGNORE_SELF_APP] = ignore }
    }

    suspend fun setAutoReconnect(enabled: Boolean) {
        context.dataStore.edit { it[Keys.AUTO_RECONNECT] = enabled }
    }

    suspend fun setKeepPresenceOnLeave(enabled: Boolean) {
        context.dataStore.edit { it[Keys.KEEP_PRESENCE_ON_LEAVE] = enabled }
    }

    suspend fun setLeaveDelaySeconds(seconds: Int) {
        context.dataStore.edit { it[Keys.LEAVE_DELAY_SECONDS] = seconds.coerceIn(1, 3600) }
    }

    suspend fun setCustomElapsed(enabled: Boolean, minutes: Int, seconds: Int) {
        context.dataStore.edit {
            it[Keys.CUSTOM_ELAPSED_ENABLED] = enabled
            it[Keys.CUSTOM_ELAPSED_MINUTES] = minutes.coerceIn(0, 1440)
            it[Keys.CUSTOM_ELAPSED_SECONDS] = seconds.coerceIn(0, 59)
            it[Keys.CUSTOM_ELAPSED_VERSION] = System.currentTimeMillis()
        }
    }

    suspend fun setDefaultApplicationId(appId: String) {
        context.dataStore.edit {
            it[Keys.DEFAULT_APP_ID] = appId.trim().ifBlank { RichPresencePayload.DEFAULT_DISCORD_APP_ID }
        }
    }

    suspend fun saveCustomRpc(payload: RichPresencePayload) {
        context.dataStore.edit { prefs ->
            prefs[Keys.CUSTOM_NAME] = payload.name
            prefs[Keys.CUSTOM_DETAILS] = payload.details
            prefs[Keys.CUSTOM_STATE] = payload.state
            prefs[Keys.CUSTOM_TYPE_CODE] = payload.activityType.code
            prefs[Keys.CUSTOM_APP_ID] = payload.applicationId.ifBlank { RichPresencePayload.DEFAULT_DISCORD_APP_ID }
            prefs[Keys.CUSTOM_LARGE_IMG] = payload.largeImageUrl
            prefs[Keys.CUSTOM_LARGE_TXT] = payload.largeImageText
            prefs[Keys.CUSTOM_SMALL_IMG] = payload.smallImageUrl
            prefs[Keys.CUSTOM_SMALL_TXT] = payload.smallImageText
            prefs[Keys.CUSTOM_BTN1_LABEL] = payload.button1Label
            prefs[Keys.CUSTOM_BTN1_URL] = payload.button1Url
            prefs[Keys.CUSTOM_BTN2_LABEL] = payload.button2Label
            prefs[Keys.CUSTOM_BTN2_URL] = payload.button2Url
            prefs[Keys.CUSTOM_SHOW_ELAPSED] = payload.startTimestampMs != null
        }
    }
}
