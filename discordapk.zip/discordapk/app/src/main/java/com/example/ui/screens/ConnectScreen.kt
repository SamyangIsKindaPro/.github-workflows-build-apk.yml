package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ContentPaste
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.ExpandLess
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.LinkOff
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.R
import com.example.data.model.GatewayStatus
import com.example.ui.MainUiState
import com.example.ui.theme.AlertCoral
import com.example.ui.theme.Blurple
import com.example.ui.theme.IdleAmber
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.OnlineGreenBright
import kotlin.math.roundToInt

@Composable
fun ConnectScreen(
    uiState: MainUiState,
    onConnectDiscord: (String) -> Unit,
    onDisconnectDiscord: () -> Unit,
    onSetPollingInterval: (Int) -> Unit,
    onSetShowElapsed: (Boolean) -> Unit,
    onSetIgnoreSelf: (Boolean) -> Unit,
    onSetAutoReconnect: (Boolean) -> Unit,
    onSetKeepPresenceOnLeave: (Boolean) -> Unit,
    onSetLeaveDelaySeconds: (Int) -> Unit,
    onSetCustomElapsed: (Boolean, Int, Int) -> Unit,
    onSetDefaultAppId: (String) -> Unit,
    onClearLogs: () -> Unit,
    modifier: Modifier = Modifier
) {
    val prefs = uiState.preferences
    val gw = uiState.gatewayState
    val clipboard = LocalClipboardManager.current

    var tokenInput by remember { mutableStateOf(prefs.discordToken) }
    var showToken by remember { mutableStateOf(false) }
    var showGuide by remember { mutableStateOf(false) }
    var defaultAppIdInput by remember { mutableStateOf(prefs.defaultApplicationId) }
    var sliderValue by remember { mutableFloatStateOf(prefs.pollingIntervalSec.toFloat()) }

    LaunchedEffect(prefs.discordToken) {
        if (tokenInput.isEmpty() && prefs.discordToken.isNotEmpty()) {
            tokenInput = prefs.discordToken
        }
    }
    LaunchedEffect(prefs.pollingIntervalSec) {
        sliderValue = prefs.pollingIntervalSec.toFloat()
    }

    val isConnectedOrConnecting = gw.status == GatewayStatus.CONNECTED ||
        gw.status == GatewayStatus.CONNECTING ||
        gw.status == GatewayStatus.RECONNECTING

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 680.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Column {
                    Text(
                        text = "Connect & Engine",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Link Discord Gateway v10 & configure background detection",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Hero Discord Account Status Card
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    color = MaterialTheme.colorScheme.surfaceContainer,
                    border = BorderStroke(
                        1.dp,
                        if (gw.status == GatewayStatus.CONNECTED) {
                            OnlineGreenBright.copy(alpha = 0.55f)
                        } else {
                            MaterialTheme.colorScheme.outline.copy(alpha = 0.6f)
                        }
                    )
                ) {
                    Column {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(88.dp)
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.img_presence_hero),
                                contentDescription = null,
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(
                                        Brush.verticalGradient(
                                            listOf(
                                                Color.Transparent,
                                                MaterialTheme.colorScheme.surfaceContainer
                                            )
                                        )
                                    )
                            )
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp)
                                .padding(bottom = 16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            val user = gw.user
                            if (!user?.avatarUrl.isNullOrBlank()) {
                                AsyncImage(
                                    model = user?.avatarUrl,
                                    contentDescription = "Connected Discord user avatar",
                                    modifier = Modifier
                                        .size(56.dp)
                                        .clip(CircleShape),
                                    contentScale = ContentScale.Crop
                                )
                            } else {
                                Box(
                                    modifier = Modifier
                                        .size(56.dp)
                                        .clip(CircleShape)
                                        .background(Blurple.copy(alpha = 0.25f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Person,
                                        contentDescription = null,
                                        tint = Blurple,
                                        modifier = Modifier.size(28.dp)
                                    )
                                }
                            }

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = user?.displayName ?: "Discord Gateway Offline",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = when (gw.status) {
                                        GatewayStatus.CONNECTED -> {
                                            val pingStr = gw.pingMs?.let { " • ${it}ms" }.orEmpty()
                                            "@${user?.username ?: "connected"}$pingStr"
                                        }
                                        GatewayStatus.CONNECTING -> "Opening wss://gateway.discord.gg..."
                                        GatewayStatus.RECONNECTING -> "Reconnecting to Gateway..."
                                        GatewayStatus.ERROR -> gw.errorMessage ?: "Connection failed"
                                        GatewayStatus.DISCONNECTED -> "Local mobile preview works without a token"
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = when (gw.status) {
                                        GatewayStatus.CONNECTED -> OnlineGreenBright
                                        GatewayStatus.ERROR -> AlertCoral
                                        GatewayStatus.CONNECTING, GatewayStatus.RECONNECTING -> IdleAmber
                                        GatewayStatus.DISCONNECTED -> MaterialTheme.colorScheme.onSurfaceVariant
                                    },
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }

            // Discord Token Connection Card
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.surfaceContainer,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.55f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "Discord Gateway Token",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )

                        OutlinedTextField(
                            value = tokenInput,
                            onValueChange = { tokenInput = it },
                            label = { Text("Account Token") },
                            placeholder = { Text("Paste Discord token to sync live RPC") },
                            singleLine = true,
                            visualTransformation = if (showToken) {
                                VisualTransformation.None
                            } else {
                                PasswordVisualTransformation()
                            },
                            trailingIcon = {
                                Row {
                                    IconButton(
                                        onClick = {
                                            clipboard.getText()?.text?.let { tokenInput = it.trim() }
                                        }
                                    ) {
                                        Icon(Icons.Rounded.ContentPaste, contentDescription = "Paste token")
                                    }
                                    IconButton(onClick = { showToken = !showToken }) {
                                        Icon(
                                            imageVector = if (showToken) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                                            contentDescription = if (showToken) "Hide token" else "Show token"
                                        )
                                    }
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("discord_token_input")
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            if (isConnectedOrConnecting) {
                                OutlinedButton(
                                    onClick = onDisconnectDiscord,
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(48.dp)
                                        .testTag("discord_disconnect_button"),
                                    shape = RoundedCornerShape(14.dp),
                                    border = BorderStroke(1.dp, AlertCoral)
                                ) {
                                    Icon(
                                        Icons.Rounded.LinkOff,
                                        contentDescription = null,
                                        tint = AlertCoral,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Disconnect", color = AlertCoral)
                                }
                            }

                            Button(
                                onClick = { onConnectDiscord(tokenInput) },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("discord_connect_button"),
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Blurple,
                                    contentColor = Color.White
                                )
                            ) {
                                Icon(Icons.Rounded.Link, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(if (isConnectedOrConnecting) "Reconnect" else "Connect Gateway")
                            }
                        }

                        // Expandable guide
                        Surface(
                            onClick = { showGuide = !showGuide },
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Icon(
                                            Icons.Rounded.Info,
                                            contentDescription = null,
                                            tint = Blurple,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Text(
                                            text = "How Gateway Sync Works",
                                            style = MaterialTheme.typography.labelLarge
                                        )
                                    }
                                    Icon(
                                        imageVector = if (showGuide) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore,
                                        contentDescription = null
                                    )
                                }

                                AnimatedVisibility(visible = showGuide) {
                                    Text(
                                        text = "PulseRPC connects directly from your phone to wss://gateway.discord.gg/?v=10&encoding=json and sends OP 3 Presence Updates when your foreground app or media track changes. Your token is stored only in encrypted/private app storage on this device.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.padding(top = 8.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Detection & Broadcast Preferences
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.surfaceContainer,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.55f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Text(
                            text = "Broadcast Engine",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )

                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "App Poll Interval",
                                    style = MaterialTheme.typography.bodyLarge
                                )
                                Text(
                                    text = "${sliderValue.roundToInt()}s",
                                    style = MaterialTheme.typography.labelLarge.copy(
                                        fontFamily = JetBrainsMonoFamily
                                    ),
                                    color = Blurple
                                )
                            }
                            Slider(
                                value = sliderValue,
                                onValueChange = { sliderValue = it },
                                onValueChangeFinished = {
                                    onSetPollingInterval(sliderValue.roundToInt())
                                },
                                valueRange = 2f..15f,
                                steps = 12,
                                modifier = Modifier.testTag("polling_interval_slider")
                            )
                        }

                        SettingSwitchRow(
                            title = "Show Elapsed Time",
                            subtitle = "Attach live session start timestamp to Rich Presence",
                            checked = prefs.showElapsedTimer,
                            onCheckedChange = onSetShowElapsed,
                            testTag = "setting_elapsed_switch"
                        )

                        SettingSwitchRow(
                            title = "Ignore PulseRPC",
                            subtitle = "Keep previous game/app active when opening PulseRPC",
                            checked = prefs.ignoreSelfApp,
                            onCheckedChange = onSetIgnoreSelf,
                            testTag = "setting_ignore_self_switch"
                        )

                        SettingSwitchRow(
                            title = "Auto-Reconnect Gateway",
                            subtitle = "Automatically recover WebSocket after network switches",
                            checked = prefs.autoReconnect,
                            onCheckedChange = onSetAutoReconnect,
                            testTag = "setting_autoreconnect_switch"
                        )

                        SettingSwitchRow(
                            title = "Keep Presence After Leaving (${prefs.leaveDelaySeconds}s)",
                            subtitle = "Hold presence for a grace duration and resume timer if you reopen the same app",
                            checked = prefs.keepPresenceOnLeaveEnabled,
                            onCheckedChange = onSetKeepPresenceOnLeave,
                            testTag = "setting_keep_leave_switch"
                        )

                        if (prefs.keepPresenceOnLeaveEnabled) {
                            var delayInput by remember(prefs.leaveDelaySeconds) {
                                mutableStateOf(prefs.leaveDelaySeconds.toString())
                            }
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedTextField(
                                    value = delayInput,
                                    onValueChange = { value -> delayInput = value.filter { it.isDigit() } },
                                    label = { Text("Leave Delay (seconds)") },
                                    singleLine = true,
                                    modifier = Modifier.weight(1f)
                                )
                                Button(
                                    onClick = {
                                        onSetLeaveDelaySeconds(delayInput.toIntOrNull() ?: 30)
                                    },
                                    modifier = Modifier.height(54.dp),
                                    shape = RoundedCornerShape(14.dp)
                                ) {
                                    Text("Set")
                                }
                            }
                        }

                        SettingSwitchRow(
                            title = "Custom Elapsed Time (${prefs.customElapsedMinutes}m ${prefs.customElapsedSeconds}s)",
                            subtitle = "Start presence timer from a custom passed duration (e.g., 36 mins)",
                            checked = prefs.customElapsedEnabled,
                            onCheckedChange = { enabled ->
                                onSetCustomElapsed(enabled, prefs.customElapsedMinutes, prefs.customElapsedSeconds)
                            },
                            testTag = "setting_custom_elapsed_switch"
                        )

                        if (prefs.customElapsedEnabled) {
                            var minInput by remember(prefs.customElapsedMinutes) {
                                mutableStateOf(prefs.customElapsedMinutes.toString())
                            }
                            var secInput by remember(prefs.customElapsedSeconds) {
                                mutableStateOf(prefs.customElapsedSeconds.toString())
                            }
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedTextField(
                                    value = minInput,
                                    onValueChange = { value -> minInput = value.filter { it.isDigit() } },
                                    label = { Text("Minutes") },
                                    singleLine = true,
                                    modifier = Modifier.weight(1f)
                                )
                                OutlinedTextField(
                                    value = secInput,
                                    onValueChange = { value -> secInput = value.filter { it.isDigit() } },
                                    label = { Text("Seconds") },
                                    singleLine = true,
                                    modifier = Modifier.weight(1f)
                                )
                                Button(
                                    onClick = {
                                        onSetCustomElapsed(
                                            true,
                                            minInput.toIntOrNull() ?: 36,
                                            secInput.toIntOrNull() ?: 0
                                        )
                                    },
                                    modifier = Modifier.height(54.dp),
                                    shape = RoundedCornerShape(14.dp)
                                ) {
                                    Text("Apply")
                                }
                            }
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = defaultAppIdInput,
                                onValueChange = { defaultAppIdInput = it },
                                label = { Text("Default Discord App ID") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            Button(
                                onClick = { onSetDefaultAppId(defaultAppIdInput) },
                                modifier = Modifier.height(54.dp),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Text("Save")
                            }
                        }

                        OutlinedButton(
                            onClick = onClearLogs,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("clear_logs_button"),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Icon(Icons.Rounded.DeleteSweep, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Clear Recent Activity Logs")
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(12.dp)) }
        }
    }
}

@Composable
private fun SettingSwitchRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    testTag: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Text(text = title, style = MaterialTheme.typography.bodyLarge)
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            modifier = Modifier.testTag(testTag)
        )
    }
}
