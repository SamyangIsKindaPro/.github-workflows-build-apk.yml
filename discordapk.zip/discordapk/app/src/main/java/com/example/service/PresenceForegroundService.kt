package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.PulseRpcApplication
import com.example.R
import com.example.data.model.GatewayStatus
import com.example.data.model.RichPresencePayload
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class PresenceForegroundService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var pollingJob: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            val repo = (application as PulseRpcApplication).container.presenceRepository
            repo.gatewayClient.sendPresence(null)
            serviceScope.launch {
                repo.preferencesManager.setBroadcastingActive(false)
            }
            stopSelf()
            return START_NOT_STICKY
        }

        val initialNotification = buildNotification(
            RichPresencePayload(
                name = "Standby",
                details = "Hidden on Discord until you open an app",
                isStandby = true
            )
        )

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                initialNotification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            )
        } else {
            startForeground(NOTIFICATION_ID, initialNotification)
        }

        startPollingLoop()
        return START_STICKY
    }

    private fun startPollingLoop() {
        pollingJob?.cancel()
        val container = (application as PulseRpcApplication).container
        val repo = container.presenceRepository

        pollingJob = serviceScope.launch {
            repo.preferencesManager.setBroadcastingActive(true)
            val prefs = repo.preferencesFlow.first()
            if (prefs.discordToken.isNotBlank() &&
                repo.gatewayStateFlow.value.status == GatewayStatus.DISCONNECTED
            ) {
                repo.gatewayClient.connect(prefs.discordToken, prefs.autoReconnect)
            }

            while (isActive) {
                val currentPrefs = repo.preferencesFlow.first()
                if (!currentPrefs.isBroadcastingActive) {
                    repo.gatewayClient.sendPresence(null)
                    stopSelf()
                    break
                }
                val payload = repo.pollAndSyncPresence(logChanges = true)
                val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                manager.notify(NOTIFICATION_ID, buildNotification(payload))
                val nextDelayMs = if (payload.graceRemainingSeconds != null) {
                    minOf(currentPrefs.pollingIntervalSec * 1000L, 1000L)
                } else {
                    currentPrefs.pollingIntervalSec * 1000L
                }
                delay(nextDelayMs)
            }
        }
    }

    private fun buildNotification(payload: RichPresencePayload): Notification {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openPending = PendingIntent.getActivity(
            this,
            0,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, PresenceForegroundService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPending = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val contentTitle = when {
            payload.isStandby -> "PulseRPC • Standby"
            payload.graceRemainingSeconds != null -> "${payload.name} • Grace (${payload.graceRemainingSeconds}s)"
            else -> "${payload.activityType.prefixLabel} ${payload.name}"
        }
        val contentText = when {
            payload.isStandby -> "Hidden on Discord • Open an enabled app to go live"
            payload.graceRemainingSeconds != null -> "Left app • Removing presence in ${payload.graceRemainingSeconds}s"
            else -> payload.details.ifBlank { payload.state.ifBlank { "Rich Presence Live" } }
        }

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_pulse)
            .setContentTitle(contentTitle)
            .setContentText(contentText)
            .setOngoing(true)
            .setSilent(true)
            .setContentIntent(openPending)
            .addAction(0, "Stop", stopPending)
            .build()
    }

    override fun onDestroy() {
        pollingJob?.cancel()
        val repo = runCatching { (application as PulseRpcApplication).container.presenceRepository }.getOrNull()
        repo?.gatewayClient?.sendPresence(null)
        serviceScope.cancel()
        super.onDestroy()
    }

    companion object {
        const val CHANNEL_ID = "pulserpc_live_channel"
        const val NOTIFICATION_ID = 1042
        const val ACTION_STOP = "com.example.pulserpc.STOP"

        fun createNotificationChannel(context: Context) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                val channel = NotificationChannel(
                    CHANNEL_ID,
                    context.getString(R.string.notification_channel_name),
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = context.getString(R.string.notification_channel_description)
                    setShowBadge(false)
                }
                manager.createNotificationChannel(channel)
            }
        }

        fun start(context: Context) {
            createNotificationChannel(context)
            val intent = Intent(context, PresenceForegroundService::class.java)
            ContextCompat.startForegroundService(context, intent)
        }

        fun stop(context: Context) {
            val intent = Intent(context, PresenceForegroundService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }
    }
}
