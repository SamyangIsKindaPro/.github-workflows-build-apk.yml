package com.example.service

import android.app.Notification
import android.content.ComponentName
import android.content.Context
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSession
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Build
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.example.data.model.MediaTrackInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object MediaStateHolder {
    private val _currentMedia = MutableStateFlow<MediaTrackInfo?>(null)
    val currentMedia: StateFlow<MediaTrackInfo?> = _currentMedia.asStateFlow()

    fun updateMedia(track: MediaTrackInfo?) {
        _currentMedia.value = track
    }
}

class MediaNotificationListenerService : NotificationListenerService() {

    override fun onListenerConnected() {
        super.onListenerConnected()
        refreshActiveMedia()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
        if (sbn != null) {
            extractFromNotification(sbn)?.let {
                MediaStateHolder.updateMedia(it)
                return
            }
        }
        refreshActiveMedia()
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        super.onNotificationRemoved(sbn)
        refreshActiveMedia()
    }

    private fun refreshActiveMedia() {
        val sessionManager = getSystemService(Context.MEDIA_SESSION_SERVICE) as? MediaSessionManager
        val component = ComponentName(this, MediaNotificationListenerService::class.java)
        val controllers: List<MediaController> = runCatching {
            sessionManager?.getActiveSessions(component)
        }.getOrNull().orEmpty()

        val activeController = controllers.firstOrNull {
            it.playbackState?.state == PlaybackState.STATE_PLAYING
        } ?: controllers.firstOrNull()

        if (activeController != null) {
            val meta = activeController.metadata
            val title = meta?.getString(MediaMetadata.METADATA_KEY_TITLE)
                ?: meta?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
                ?: ""
            val artist = meta?.getString(MediaMetadata.METADATA_KEY_ARTIST)
                ?: meta?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
                ?: ""
            val album = meta?.getString(MediaMetadata.METADATA_KEY_ALBUM) ?: ""
            val isPlaying = activeController.playbackState?.state == PlaybackState.STATE_PLAYING

            if (title.isNotBlank()) {
                val playerLabel = resolvePackageLabel(activeController.packageName)
                MediaStateHolder.updateMedia(
                    MediaTrackInfo(
                        packageName = activeController.packageName,
                        playerName = playerLabel,
                        title = title,
                        artist = artist.ifBlank { "Unknown Artist" },
                        album = album,
                        isPlaying = isPlaying
                    )
                )
                return
            }
        }

        // Fallback to active notifications with media session
        val notifications = runCatching { activeNotifications?.toList() }.getOrNull().orEmpty()
        val mediaTrack = notifications.firstNotNullOfOrNull { extractFromNotification(it) }
        MediaStateHolder.updateMedia(mediaTrack)
    }

    private fun extractFromNotification(sbn: StatusBarNotification): MediaTrackInfo? {
        val extras = sbn.notification.extras ?: return null
        val hasMediaSession = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            extras.getParcelable(Notification.EXTRA_MEDIA_SESSION, MediaSession.Token::class.java) != null
        } else {
            @Suppress("DEPRECATION")
            extras.getParcelable<MediaSession.Token>(Notification.EXTRA_MEDIA_SESSION) != null
        }
        val isTransport = sbn.notification.category == Notification.CATEGORY_TRANSPORT
        if (!hasMediaSession && !isTransport) return null

        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim().orEmpty()
        if (title.isBlank()) return null

        val playerLabel = resolvePackageLabel(sbn.packageName)
        return MediaTrackInfo(
            packageName = sbn.packageName,
            playerName = playerLabel,
            title = title,
            artist = text.ifBlank { playerLabel },
            isPlaying = true
        )
    }

    private fun resolvePackageLabel(packageName: String): String {
        return runCatching {
            val appInfo = packageManager.getApplicationInfo(packageName, 0)
            packageManager.getApplicationLabel(appInfo).toString()
        }.getOrDefault(packageName)
    }
}
