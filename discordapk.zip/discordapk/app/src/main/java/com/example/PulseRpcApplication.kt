package com.example

import android.app.Application
import com.example.data.local.AppDatabase
import com.example.data.local.PreferencesManager
import com.example.data.remote.DiscordGatewayClient
import com.example.data.repository.PresenceRepository
import com.example.service.PresenceForegroundService

class AppContainer(application: Application) {
    private val database by lazy { AppDatabase.getInstance(application) }
    val preferencesManager by lazy { PreferencesManager(application) }
    val gatewayClient by lazy { DiscordGatewayClient() }
    val presenceRepository by lazy {
        PresenceRepository(
            context = application,
            dao = database.pulseRpcDao(),
            preferencesManager = preferencesManager,
            gatewayClient = gatewayClient
        )
    }
}

class PulseRpcApplication : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        PresenceForegroundService.createNotificationChannel(this)
    }
}
