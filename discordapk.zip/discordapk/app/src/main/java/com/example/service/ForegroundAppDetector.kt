package com.example.service

import android.app.KeyguardManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.os.PowerManager

data class DetectedForegroundApp(
    val packageName: String,
    val appName: String,
    val isGame: Boolean
)

class ForegroundAppDetector(private val context: Context) {

    @Volatile
    private var activePackage: String? = null

    private val systemUiPackages = setOf(
        "com.android.systemui",
        "com.android.permissioncontroller",
        "com.google.android.permissioncontroller",
        "com.android.packageinstaller",
        "com.google.android.packageinstaller"
    )

    fun detectCurrentApp(ignorePackageName: String? = null): DetectedForegroundApp? {
        if (!SystemPermissionHelper.hasUsageStatsPermission(context)) {
            activePackage = null
            return null
        }

        // If screen is off or locked, the user is not inside any app
        val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
        if (powerManager != null && !powerManager.isInteractive) {
            activePackage = null
            return null
        }
        val keyguardManager = context.getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
        if (keyguardManager != null && keyguardManager.isKeyguardLocked) {
            activePackage = null
            return null
        }

        val usageStatsManager = context.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager
            ?: return null

        val now = System.currentTimeMillis()
        val events = usageStatsManager.queryEvents(now - 10 * 60_000L, now)
        val event = UsageEvents.Event()

        var trackedPkg: String? = activePackage
        var latestResumeTs = 0L

        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            val pkg = event.packageName ?: continue

            val isResume = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                event.eventType == UsageEvents.Event.ACTIVITY_RESUMED
            } else {
                @Suppress("DEPRECATION")
                event.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND
            }

            val isPauseOrStop = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                event.eventType == UsageEvents.Event.ACTIVITY_PAUSED ||
                    event.eventType == UsageEvents.Event.ACTIVITY_STOPPED
            } else {
                @Suppress("DEPRECATION")
                event.eventType == UsageEvents.Event.MOVE_TO_BACKGROUND
            }

            when {
                isResume -> {
                    trackedPkg = pkg
                    latestResumeTs = event.timeStamp
                }
                isPauseOrStop && pkg == trackedPkg && event.timeStamp > latestResumeTs -> {
                    trackedPkg = null
                }
            }
        }

        activePackage = trackedPkg
        val currentPkg = trackedPkg ?: return null

        // If user is on the Home Launcher, SystemUI, or ignored PulseRPC itself, they are not inside a tracked app
        if (currentPkg == ignorePackageName ||
            systemUiPackages.contains(currentPkg) ||
            isLauncherPackage(currentPkg)
        ) {
            return null
        }

        return resolveAppInfo(currentPkg)
    }

    fun isLauncherPackage(packageName: String): Boolean {
        val pm = context.packageManager
        val homeIntent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_HOME)
        }
        val homeApps = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.queryIntentActivities(homeIntent, PackageManager.ResolveInfoFlags.of(0))
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(homeIntent, 0)
        }
        return homeApps.any { it.activityInfo?.packageName == packageName }
    }

    fun resolveAppInfo(packageName: String): DetectedForegroundApp? {
        val pm = context.packageManager
        return runCatching {
            val appInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getApplicationInfo(packageName, PackageManager.ApplicationInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                pm.getApplicationInfo(packageName, 0)
            }
            val label = pm.getApplicationLabel(appInfo).toString().ifBlank { packageName }
            val isGame = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                appInfo.category == ApplicationInfo.CATEGORY_GAME
            } else {
                @Suppress("DEPRECATION")
                (appInfo.flags and ApplicationInfo.FLAG_IS_GAME) != 0
            }
            DetectedForegroundApp(
                packageName = packageName,
                appName = label,
                isGame = isGame
            )
        }.getOrNull()
    }
}
