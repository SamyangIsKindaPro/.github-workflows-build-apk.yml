package com.example.data.remote

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

data class ResolvedAppMedia(
    val iconUrl: String,
    val discordAppId: String? = null
)

class AppIconUrlResolver {

    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    // ConcurrentHashMap does not allow null values, so wrap optional result
    private val cache = ConcurrentHashMap<String, ResolvedAppMedia>()
    private val failedPackages = ConcurrentHashMap.newKeySet<String>()

    @Volatile
    private var detectableLoaded = false
    private val detectableMap = ConcurrentHashMap<String, ResolvedAppMedia>()

    suspend fun resolveAppLogo(packageName: String): ResolvedAppMedia? {
        cache[packageName]?.let { return it }
        if (failedPackages.contains(packageName)) return null

        return withContext(Dispatchers.IO) {
            ensureDetectableLoaded()
            detectableMap[packageName]?.let { found ->
                cache[packageName] = found
                return@withContext found
            }

            val playUrl = fetchPlayStoreIconUrl(packageName)
            if (!playUrl.isNullOrBlank()) {
                val resolved = ResolvedAppMedia(iconUrl = playUrl)
                cache[packageName] = resolved
                return@withContext resolved
            }

            failedPackages.add(packageName)
            null
        }
    }

    private fun ensureDetectableLoaded() {
        if (detectableLoaded) return
        detectableLoaded = true
        runCatching {
            val req = Request.Builder()
                .url("https://discord.com/api/v9/applications/detectable")
                .header("User-Agent", "Discord-Android/245014;PulseRPC")
                .get()
                .build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@use
                val body = resp.body?.string().orEmpty()
                val arr = JSONArray(body)
                for (i in 0 until arr.length()) {
                    val obj = arr.optJSONObject(i) ?: continue
                    val appId = obj.optString("id")
                    val iconHash = obj.optString("icon").takeIf { it.isNotBlank() && it != "null" } ?: continue
                    val iconUrl = "https://cdn.discordapp.com/app-icons/$appId/$iconHash.png?size=256"
                    val executables = obj.optJSONArray("executables") ?: continue
                    for (j in 0 until executables.length()) {
                        val exe = executables.optJSONObject(j) ?: continue
                        val os = exe.optString("os")
                        val name = exe.optString("name")
                        if (os == "android" && name.isNotBlank()) {
                            detectableMap[name] = ResolvedAppMedia(iconUrl = iconUrl, discordAppId = appId)
                        }
                    }
                }
            }
        }
    }

    private fun fetchPlayStoreIconUrl(packageName: String): String? {
        return runCatching {
            val req = Request.Builder()
                .url("https://play.google.com/store/apps/details?id=$packageName&hl=en&gl=US")
                .header(
                    "User-Agent",
                    "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36"
                )
                .get()
                .build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@use null
                val html = resp.body?.string().orEmpty()
                val ogMatch = OG_IMAGE_REGEX.find(html)?.groupValues?.getOrNull(1)
                if (!ogMatch.isNullOrBlank()) {
                    return@use ogMatch.replace("=w240-h480", "=s512").replace("=s180", "=s512")
                }
                val lhMatch = PLAY_ICON_REGEX.find(html)?.value
                lhMatch?.let { "$it=s512" }
            }
        }.getOrNull()
    }

    companion object {
        private val OG_IMAGE_REGEX =
            Regex("""<meta\s+property=["']og:image["']\s+content=["']([^"']+)["']""", RegexOption.IGNORE_CASE)
        private val PLAY_ICON_REGEX =
            Regex("""https://play-lh\.googleusercontent\.com/[A-Za-z0-9_-]+""")
    }
}
