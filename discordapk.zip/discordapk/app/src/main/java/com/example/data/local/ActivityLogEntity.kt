package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "activity_logs")
data class ActivityLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val packageName: String,
    val title: String,
    val subtitle: String,
    val modeLabel: String,
    val timestampMs: Long = System.currentTimeMillis()
)
