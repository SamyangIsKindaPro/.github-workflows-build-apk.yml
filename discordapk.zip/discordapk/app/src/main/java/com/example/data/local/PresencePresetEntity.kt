package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.ActivityType
import com.example.data.model.RichPresencePayload

@Entity(tableName = "presence_presets")
data class PresencePresetEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val presetName: String,
    val applicationId: String = RichPresencePayload.DEFAULT_DISCORD_APP_ID,
    val activityName: String,
    val details: String,
    val state: String,
    val activityTypeCode: Int = ActivityType.PLAYING.code,
    val largeImageUrl: String = "",
    val largeImageText: String = "",
    val smallImageUrl: String = "",
    val smallImageText: String = "",
    val button1Label: String = "",
    val button1Url: String = "",
    val button2Label: String = "",
    val button2Url: String = "",
    val showElapsedTime: Boolean = true,
    val createdAtMs: Long = System.currentTimeMillis()
)
