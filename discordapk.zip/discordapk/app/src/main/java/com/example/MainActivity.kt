package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.MainViewModel
import com.example.ui.PulseRpcApp
import com.example.ui.theme.PulseRpcTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            PulseRpcTheme(darkTheme = true) {
                val mainViewModel: MainViewModel = viewModel(factory = MainViewModel.Factory)

                LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
                    mainViewModel.refreshOnResume()
                }

                PulseRpcApp(viewModel = mainViewModel)
            }
        }
    }
}
